﻿using AutoMapper;
using Hahn.ApplicationProcess.February2021.Domain.DTOs.Requests;
using Hahn.ApplicationProcess.February2021.Domain.DTOs.Responses;
using Hahn.ApplicationProcess.February2021.Domain.Models;
using System;

namespace Hahn.ApplicationProcess.February2021.Domain.Mappings
{
    public class AssetProfile : Profile
    {
        public AssetProfile()
        {
            CreateMap<CreateAssetDTO, Asset>()
                .ForMember(d => d.CreatedOn, opt => opt.MapFrom(s => DateTime.UtcNow))
                .ForMember(d => d.UpdatedOn, opt => opt.MapFrom(s => DateTime.UtcNow));

            CreateMap<UpdateAssetDTO, Asset>()
                .ForMember(d => d.UpdatedOn, opt => opt.MapFrom(s => DateTime.UtcNow));


            CreateMap<Asset, AssetDTO>()
                .ForMember(d => d.DepartmentId, opt => opt.MapFrom(s => s.Department));
        }
    }
}
