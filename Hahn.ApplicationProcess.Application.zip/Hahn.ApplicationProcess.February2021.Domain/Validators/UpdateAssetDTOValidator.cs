﻿using FluentValidation;
using Hahn.ApplicationProcess.February2021.Domain.DTOs.Requests;
using Hahn.ApplicationProcess.February2021.Domain.Interfaces.HTTPDataAccess;
using Hahn.ApplicationProcess.February2021.Domain.Validators.CustomValidators;
using Microsoft.AspNetCore.Http;
using System;

namespace Hahn.ApplicationProcess.February2021.Domain.Validators
{
    public class UpdateAssetDTOValidator : AbstractValidator<UpdateAssetDTO>
    {

        public UpdateAssetDTOValidator(ICountryService countryService, IHttpContextAccessor httpContext)
        {
            RuleFor(x => x.AssetName).MinimumLength(5).NotEmpty();
            RuleFor(x => x.Department).IsInEnum().WithMessage("The department does not exists!");
            RuleFor(x => x.EMailAddressOfDepartment).Matches(@"^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"); RuleFor(x => x.CountryOfDepartment).CountryValidator(countryService);
            RuleFor(x => x.Broken).BrokenValidator(httpContext);
            RuleFor(x => x.PurchaseDate).NotEmpty().Must(date => DateTime.Today.Subtract(date).Days <= 365).WithMessage("Purchase date must not be older than 1 year");

        }
    }
}
