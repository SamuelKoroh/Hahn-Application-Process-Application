﻿using FluentValidation;
using Hahn.ApplicationProcess.February2021.Domain.Interfaces.HTTPDataAccess;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Hahn.ApplicationProcess.February2021.Domain.Validators.CustomValidators
{
    public static class RuleBuilderExtensions
    {
        public static IRuleBuilder<T, string> CountryValidator<T>(this IRuleBuilder<T, string> ruleBuilder, ICountryService countryService)
        {
            return ruleBuilder.MustAsync(async (country, cancellation) => await countryService.DoesCountryExists(country)).WithMessage("Country does not exists!");
        }

        public static IRuleBuilder<T, bool?> BrokenValidator<T>(this IRuleBuilder<T, bool?> ruleBuilder, IHttpContextAccessor httpContext)
        {
            return ruleBuilder.MustAsync(async (x, c) =>
            {
                httpContext.HttpContext.Request.Body.Seek(0, SeekOrigin.Begin);

                using var reader = new StreamReader(httpContext.HttpContext.Request.Body, encoding: Encoding.UTF8, detectEncodingFromByteOrderMarks: false);

                var bodyString = await reader.ReadToEndAsync();

                IDictionary<string, JToken> dictionary = JObject.Parse(bodyString);

                if (dictionary.ContainsKey("broken"))
                {
                    var value = (bool?)dictionary["broken"];

                    return value != null;
                };

                return true;
            })
                .WithMessage("Broken value cannot be null if provided");
        }

        public static IRuleBuilderInitial<T, DateTime> PurchaseDateValidator<T, TElement>(this IRuleBuilder<T, DateTime> ruleBuilder, int num)
        {

            return ruleBuilder.Custom((date, context) => {
                if ((DateTime.UtcNow - date).TotalDays >= num)
                {
                    context.AddFailure($"Purchase date must not be older then {num} year");
                }
            });
        }
    }
}
