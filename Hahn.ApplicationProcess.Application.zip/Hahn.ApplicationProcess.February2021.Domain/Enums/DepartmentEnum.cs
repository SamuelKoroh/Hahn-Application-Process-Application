﻿using System.ComponentModel;

namespace Hahn.ApplicationProcess.February2021.Domain.Enums
{
    public enum DepartmentEnum
    {
        [Description("Head Quarter")]
        HQ = 1,

        [Description("Store 1")]
        Store1,

        [Description("Store 2")]
        Store2,

        [Description("Store 3")]
        Store3,

        [Description("Maintenance Station")]
        MaintenanceStation
    }
}
