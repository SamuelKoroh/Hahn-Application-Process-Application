﻿using System;

namespace Hahn.ApplicationProcess.February2021.Domain.Utilities
{
    public class PaginationMetaData
    {
        public PaginationMetaData(int page, int pageSize, int totalItems)
        {
            PageNumber = page == 0 ? 1 : page;
            PageSize = pageSize < 1 || pageSize > 50 ? 20 : pageSize;
            PageCount = (int)Math.Ceiling(totalItems / (double)PageSize);
            TotalItemCount = totalItems;
        }

        public int PageNumber { get; set; }
        public bool HasNextPage { get { return PageNumber < PageCount; } }
        public bool HasPreviousPage { get { return PageNumber > 1; } }
        public int PageCount { get; set; }
        public int PageSize { get; set; }
        public int TotalItemCount { get; set; }
    }
}
