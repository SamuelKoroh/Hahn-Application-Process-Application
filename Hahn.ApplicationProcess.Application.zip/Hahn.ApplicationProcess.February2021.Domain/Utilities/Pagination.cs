﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicationProcess.February2021.Domain.Utilities
{
    public static class Pagination
    {
        public static (List<T>, PaginationMetaData) ApplyPaging<T>(this IQueryable<T> query, int page, int pageSize)
        {
            if (page < 1)
                page = 1;

            if (pageSize < 1 || pageSize > 50)
                pageSize = 20;

            var items =  query.Skip((page - 1) * pageSize).Take(pageSize).ToList();
            var pagingData = new PaginationMetaData(page, pageSize, query.Count());

            return (items, pagingData);
        }
    }
}
