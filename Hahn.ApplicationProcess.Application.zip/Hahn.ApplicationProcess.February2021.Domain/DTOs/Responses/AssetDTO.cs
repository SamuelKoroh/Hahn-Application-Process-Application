﻿using System;

namespace Hahn.ApplicationProcess.February2021.Domain.DTOs.Responses
{
    public class AssetDTO
    {
        public int Id { get; set; }
        public string AssetName { get; set; }
        public string Department { get; set; }
        public int DepartmentId { get; set; }
        public string CountryOfDepartment { get; set; }
        public string EMailAddressOfDepartment { get; set; }
        public DateTime PurchaseDate { get; set; }
        public bool Broken { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime UpdatedOn { get; set; }
    }

    public class DepartmentDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Key { get; set; }
    }
}
