﻿namespace Hahn.ApplicationProcess.February2021.Domain.DTOs.Responses
{
    public class OperationResponse<T>
    {
        public OperationResponse(string message, T data = default, bool success = false)
        {
            Message = message;
            Data = data;
            Success = success;
        }

        public bool Success { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }
    }
}
