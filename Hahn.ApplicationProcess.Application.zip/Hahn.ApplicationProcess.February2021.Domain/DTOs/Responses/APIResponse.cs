﻿using Hahn.ApplicationProcess.February2021.Domain.Utilities;

namespace Hahn.ApplicationProcess.February2021.Domain.DTOs.Responses
{
    public class SuccessResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }
    }

    public class SuccessPagingResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }
        public PaginationMetaData Paging { get; set; }
    }

    public class ErrorResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public object Errors { get; set; }
    }

    public class APIResponse
    {
        public static SuccessPagingResponse<T> Success<T>(string message, T data, PaginationMetaData pagination)
        {
            return new SuccessPagingResponse<T>
            {
                Success = true,
                Message = message,
                Data = data,
                Paging = pagination
            };
        }

        public static SuccessResponse<T> Success<T>(string message, T data = default)
            where T : class
        {
            return new SuccessResponse<T>
            {
                Success = true,
                Message = message,
                Data = data
            };
        }

        public static ErrorResponse Error(string message)
        {
            return new ErrorResponse
            {
                Success = false,
                Message = message
            };
        }
    }
}
