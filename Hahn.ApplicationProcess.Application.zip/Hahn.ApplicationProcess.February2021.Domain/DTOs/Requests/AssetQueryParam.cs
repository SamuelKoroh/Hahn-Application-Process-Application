﻿using Hahn.ApplicationProcess.February2021.Domain.Enums;

namespace Hahn.ApplicationProcess.February2021.Domain.DTOs.Requests
{
    public class AssetQueryParam
    {
        public int Page { get; set; }
        public int PageSize { get; set; }
        public DepartmentEnum? departmentId { get; set; }
    }
}
