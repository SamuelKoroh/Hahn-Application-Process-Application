﻿using Hahn.ApplicationProcess.February2021.Domain.Enums;
using System;

namespace Hahn.ApplicationProcess.February2021.Domain.DTOs.Requests
{
    public class UpdateAssetDTO
    {
        public string AssetName { get; set; }
        public DepartmentEnum Department { get; set; }
        public string CountryOfDepartment { get; set; }
        public string EMailAddressOfDepartment { get; set; }
        public DateTime PurchaseDate { get; set; }
        public bool? Broken { get; set; }
    }
}
