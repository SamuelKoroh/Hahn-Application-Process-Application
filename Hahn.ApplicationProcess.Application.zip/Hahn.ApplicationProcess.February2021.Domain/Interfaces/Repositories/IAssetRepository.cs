﻿using Hahn.ApplicationProcess.February2021.Domain.Models;

namespace Hahn.ApplicationProcess.February2021.Domain.Interfaces.Repositories
{
    public interface IAssetRepository : IRepository<Asset>
    {
    }
}
