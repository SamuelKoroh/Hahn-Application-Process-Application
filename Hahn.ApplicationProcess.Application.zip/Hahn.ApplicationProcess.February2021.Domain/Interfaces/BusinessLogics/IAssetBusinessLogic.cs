﻿using Hahn.ApplicationProcess.February2021.Domain.DTOs.Responses;
using Hahn.ApplicationProcess.February2021.Domain.Enums;
using Hahn.ApplicationProcess.February2021.Domain.Models;
using Hahn.ApplicationProcess.February2021.Domain.Utilities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Hahn.ApplicationProcess.February2021.Domain.Interfaces.BusinessLogics
{
    public interface IAssetBusinessLogic
    {
        Task<OperationResponse<Asset>> CreateAsset(Asset asset);
        Task<OperationResponse<Asset>> DeleteAsset(int assetId);
        OperationResponse<List<DepartmentDTO>> Departments();
        Task<OperationResponse<Asset>> GetAsset(int assetId);
        Task<OperationResponse<(IEnumerable<Asset>, PaginationMetaData)>> GetAssets(int page = 1, int pageSize = 20, DepartmentEnum? departmentId = null);
        Task<OperationResponse<Asset>> UpdateAsset(Asset asset);
    }
}
