﻿using System.Threading.Tasks;

namespace Hahn.ApplicationProcess.February2021.Domain.Interfaces.HTTPDataAccess
{
    public interface ICountryService
    {
        Task<bool> DoesCountryExists(string countrtyFullName);
    }
}
