﻿using Hahn.ApplicationProcess.February2021.Domain.Interfaces.Repositories;
using System;
using System.Threading.Tasks;

namespace Hahn.ApplicationProcess.February2021.Domain.Interfaces.DataAccess
{
    public interface IUnitOfWork : IDisposable
    {
        public IAssetRepository Assets { get; set; }
        Task<bool> SaveChangesAsync();
    }
}
