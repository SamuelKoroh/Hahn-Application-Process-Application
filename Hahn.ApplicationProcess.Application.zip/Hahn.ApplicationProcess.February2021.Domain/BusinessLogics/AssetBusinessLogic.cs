﻿using Hahn.ApplicationProcess.February2021.Domain.DTOs.Responses;
using Hahn.ApplicationProcess.February2021.Domain.Enums;
using Hahn.ApplicationProcess.February2021.Domain.Interfaces.BusinessLogics;
using Hahn.ApplicationProcess.February2021.Domain.Interfaces.DataAccess;
using Hahn.ApplicationProcess.February2021.Domain.Models;
using Hahn.ApplicationProcess.February2021.Domain.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Hahn.ApplicationProcess.February2021.Domain.BusinessLogics
{
    public class AssetBusinessLogic : IAssetBusinessLogic
    {
        private readonly IUnitOfWork _unitOfWork;

        public AssetBusinessLogic(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<OperationResponse<Asset>> CreateAsset(Asset asset)
        {
            if (await _unitOfWork.Assets.AnyAsync(x => x.AssetName.ToLower().Trim() == asset.AssetName.ToLower().Trim()))
                return new OperationResponse<Asset>("Asset with this name already exists!");

            await _unitOfWork.Assets.AddAsync(asset);
            await _unitOfWork.SaveChangesAsync();

            return new OperationResponse<Asset>("Asset created successfully", asset, true);
        }

        public async Task<OperationResponse<Asset>> DeleteAsset(int assetId)
        {
            var asset = await _unitOfWork.Assets.SingleorDefaultAsync(x => x.Id == assetId);

            if (asset == null)
                return new OperationResponse<Asset>("Asset not found!", success: false);

            _unitOfWork.Assets.Remove(asset);
            await _unitOfWork.SaveChangesAsync();

            return new OperationResponse<Asset>("Assets deleted successfully", asset, true);
        }

        public async Task<OperationResponse<Asset>> GetAsset(int assetId)
        {
            var asset = await _unitOfWork.Assets.SingleorDefaultAsync(x => x.Id == assetId);

            if (asset == null)
                return new OperationResponse<Asset>("Asset not found!", success: false);

            return new OperationResponse<Asset>("Asset retrieved successfully", asset, true);
        }

        public async Task<OperationResponse<(IEnumerable<Asset>, PaginationMetaData)>> GetAssets(int page, int pageSize, DepartmentEnum? departmentId = null)
        {
            var query = _unitOfWork.Assets.Queryable();

            if (departmentId.HasValue)
               query = query.Where(x => x.Department == departmentId);

            var assets = await Task.FromResult(query.ApplyPaging(page, pageSize));

            return new OperationResponse<(IEnumerable<Asset>, PaginationMetaData)>("Assets retrieved successfully", assets, true);
        }

        public async Task<OperationResponse<Asset>> UpdateAsset(Asset asset)
        {
            if (await _unitOfWork.Assets.AnyAsync(x => x.Id != asset.Id && x.AssetName.ToLower().Trim() == asset.AssetName.ToLower().Trim()))
                return new OperationResponse<Asset>("Asset with this name already exists!");

            await _unitOfWork.SaveChangesAsync();

            return new OperationResponse<Asset>("Asset updated successfully", asset, true);

        }

        public OperationResponse<List<DepartmentDTO>> Departments()
        {
            var departments = new List<DepartmentDTO>();
            var enumType = typeof(DepartmentEnum);

            foreach (var department in Enum.GetNames(enumType))
            {
                var member = enumType.GetMember(department);
                var displayAttribute = member[0].GetCustomAttribute<DescriptionAttribute>();
                var id = (DepartmentEnum)Enum.Parse(enumType, department, false);

                departments.Add(new DepartmentDTO { Id = (int)id, Name = displayAttribute.Description, Key = id.ToString().ToLower()});
            }

            return new OperationResponse<List<DepartmentDTO>>("Departments retrieved successfully", departments, true);
        }
    }
}
