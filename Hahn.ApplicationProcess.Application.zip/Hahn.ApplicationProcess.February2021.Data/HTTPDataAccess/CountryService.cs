﻿using Hahn.ApplicationProcess.February2021.Domain.Interfaces.HTTPDataAccess;
using System.Net.Http;
using System.Threading.Tasks;

namespace Hahn.ApplicationProcess.February2021.Data.HTTPDataAccess
{
    public class CountryService : ICountryService
    {
        private readonly HttpClient _httpClient;

        public CountryService(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient("RestCountries");
        }

        public async Task<bool> DoesCountryExists(string countrtyFullName)
        {
            var response = await _httpClient.GetAsync($"/rest/v2/name/{countrtyFullName}?fullText=true");

            return response.IsSuccessStatusCode;
        }
    }
}
