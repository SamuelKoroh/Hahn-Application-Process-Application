﻿using Hahn.ApplicationProcess.February2021.Data.DataAccess.Repositories;
using Hahn.ApplicationProcess.February2021.Domain.Interfaces.DataAccess;
using Hahn.ApplicationProcess.February2021.Domain.Interfaces.Repositories;
using System;
using System.Threading.Tasks;

namespace Hahn.ApplicationProcess.February2021.Data.DataAccess
{
    public class UnitOfWork : IUnitOfWork
    {
        public IAssetRepository Assets { get; set; }
        private readonly DataContext _context;

        public UnitOfWork(DataContext context)
        {
            _context = context;
            Assets = new AssetRepository(_context);
        }

        public void Dispose()
        {
            _context.Dispose();
            GC.SuppressFinalize(this);
        }

        public async Task<bool> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
