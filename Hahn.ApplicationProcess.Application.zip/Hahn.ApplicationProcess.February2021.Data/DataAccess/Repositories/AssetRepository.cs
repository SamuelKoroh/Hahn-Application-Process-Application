﻿using Hahn.ApplicationProcess.February2021.Domain.Interfaces.Repositories;
using Hahn.ApplicationProcess.February2021.Domain.Models;

namespace Hahn.ApplicationProcess.February2021.Data.DataAccess.Repositories
{
    public class AssetRepository : Repository<Asset>, IAssetRepository
    {
        public AssetRepository(DataContext context) : base(context)
        {
        }

        public DataContext DataContext { get { return Context as DataContext; } }
    }
}
