const webpack = require("webpack");
const HtmlWebpackPlugin = require('html-webpack-plugin');
const merge = require('webpack-merge');
const common = require('./webpack.common')

module.exports = merge(common, {
  mode: 'development',
  devtool: 'inline-source-map',
  watch: true,
  module: {
    rules: [
      {
        test: /\.s?css$/,
        use: ['style-loader', 'css-loader']
      }
    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: 'index.ejs',
        metadata: { dev: true },
        filename: "../../wwwroot/index.html",
        inject: false,
        alwaysWriteToDisk: true
    }),
    new webpack.DefinePlugin({ IS_DEV_BUILD: true })
  ]
});