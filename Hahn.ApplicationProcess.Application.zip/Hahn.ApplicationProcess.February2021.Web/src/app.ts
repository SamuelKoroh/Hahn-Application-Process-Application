import { LocaleService } from './services/locale-service';
import { inject, PLATFORM, } from 'aurelia-framework';
import { Router, RouterConfiguration } from 'aurelia-router';
import { I18N } from 'aurelia-i18n';

@inject(I18N, LocaleService)
export class App {
  router: Router;
  localeService: LocaleService;

  constructor(LocaleService){
    this.localeService = LocaleService;
  }
  
  configureRouter(config: RouterConfiguration, router: Router){
    config.title = 'Asset Manager';
    config.map([
      { route:  ['', 'home'], name:'home', moduleId: PLATFORM.moduleName('components/asset-list'), title:'' },
      { route: 'create-asset', name:'create-asset', moduleId: PLATFORM.moduleName('components/asset-form'), title:'Create Asset' },
      { route: 'asset-details/:id', name:'asset-details', moduleId: PLATFORM.moduleName('components/asset-details'), title:'Asset Details' },
      { route: 'edit-asset/:id', name:'edit-asset', moduleId: PLATFORM.moduleName('components/asset-form'), title:'Edit Asset Details' }
    ]);
    this.router = router;
  }

  setLocale(language){
    this.localeService.setLocale(language);
  }
 
}
