import { inject } from 'aurelia-dependency-injection';
import {HttpClient } from 'aurelia-http-client';

@inject(HttpClient)
export class CountryService {
    httpClient: HttpClient;

    constructor(){
        this.httpClient = new HttpClient();

        this.httpClient = this.httpClient.configure(x => {
            x.withBaseUrl('https://restcountries.eu');
          });
    }
    
    async validateCountry(countrtyFullName: string) : Promise<boolean> {
        try {
            const res = await this.httpClient.get(`/rest/v2/name/${countrtyFullName}?fullText=true`);
            return res.isSuccess;
        } catch (error) {
            return false;
        }
    }
}