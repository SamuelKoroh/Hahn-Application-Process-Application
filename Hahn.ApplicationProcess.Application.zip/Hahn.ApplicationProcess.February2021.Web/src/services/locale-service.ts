import { inject } from 'aurelia-dependency-injection';
import { I18N } from 'aurelia-i18n';
import {BindingSignaler} from 'aurelia-templating-resources';
import {EventAggregator} from 'aurelia-event-aggregator';

@inject(I18N, BindingSignaler, EventAggregator)
export class LocaleService {
   private i18N: I18N;

    constructor(I18N){
        this.i18N = I18N;
    }

    translate(key: string){
        return this.i18N.tr(key);
    }

    setLocale(language){
        this.i18N.setLocale(language);
      }
}
