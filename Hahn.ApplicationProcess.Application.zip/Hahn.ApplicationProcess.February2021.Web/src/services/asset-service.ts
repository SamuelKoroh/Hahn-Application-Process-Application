import { inject } from 'aurelia-dependency-injection';
import {HttpClient, HttpResponseMessage,} from 'aurelia-http-client';
import { IError, ISuccessResponse, IAsset, ICreateAsset } from '../interfaces/asset-interface';

@inject(HttpClient)
export class AssetService {
    httpClient: HttpClient;

    constructor(httpClient){
        this.httpClient = httpClient;
    }
    
    public createAsset = async (asset: ICreateAsset): Promise<ISuccessResponse<IAsset> | IError> => {
        try {
            const response = await this.httpClient.post('/api/v1/assets', asset);
            return response.statusCode === 201 && JSON.parse(response.response);
        } catch (error) {
            return JSON.parse(error.response);
        }
    }

    public updateAsset = async (asset: ICreateAsset, assetId: number): Promise<ISuccessResponse<IAsset> | IError> => {
        try {
            const response = await this.httpClient.put(`/api/v1/assets/${assetId}`, asset);
            return response.statusCode === 200 && JSON.parse(response.response);
        } catch (error) {
            return JSON.parse(error.response);
        }
    }

    async getDepartments() {
        try {
            return await this.httpClient.get('/api/v1/assets/departments');
        } catch (error) {
            console.log(error);
        }
    }

    async getAssets(departmentId: number | undefined = undefined, page: number = 1, pageSize: number = 50) {
        try {
            return await this.httpClient.get(`/api/v1/assets?page=${page}&pageSize=${pageSize}${departmentId !==undefined ? `&departmentId=${departmentId}`:''}`);
        } catch (error) {
            console.log(error);
        }
    }

    public getAsset = async(id: number) : Promise<ISuccessResponse<IAsset> | IError> =>{
        try {
            const response = await this.httpClient.get(`/api/v1/assets/${id}`);
            return response.statusCode === 200 && JSON.parse(response.response);
        } catch (error) {
            console.log(error);
            return JSON.parse(error.response);
        }
    }

    public deleteAsset = async(id: number) : Promise<ISuccessResponse<IAsset> | IError> =>{
        try {
            const response = await this.httpClient.delete(`/api/v1/assets/${id}`);
            return response.statusCode === 200 && JSON.parse(response.response);
        } catch (error) {
            console.log(error);
            return JSON.parse(error.response);
        }
    }
}