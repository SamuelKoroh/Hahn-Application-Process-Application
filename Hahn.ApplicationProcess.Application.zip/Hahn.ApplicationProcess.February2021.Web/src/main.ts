import { Aurelia, PLATFORM } from 'aurelia-framework';
import { Backend, TCustomAttribute } from 'aurelia-i18n';
var resBundle = require(
  "i18next-resource-store-loader!./locales/index"
);
import 'bootstrap/dist/css/bootstrap.css';
require('popper.js');
require('jquery');
require('bootstrap');
import './styles/custom.css';
import 'eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css';
import 'aurelia-bootstrap-datetimepicker/dist/amd/bootstrap-datetimepicker-bs4.css';
import 'font-awesome/css/font-awesome.css';


export async function configure(au: Aurelia) {
  au.use.standardConfiguration()
  .developmentLogging()
  .router()
  .defaultBindingLanguage()
  .plugin(PLATFORM.moduleName('aurelia-validation'))
  .plugin(PLATFORM.moduleName('aurelia-dialog'), config => {
    config.useDefaults();
    })
  .plugin(PLATFORM.moduleName('aurelia-bootstrap-datetimepicker'), config => {
    config.extra.bootstrapVersion = 4;
    config.extra.buttonClass = 'btn btn-outline-secondary';
  })
  .plugin(PLATFORM.moduleName('aurelia-i18n'), (instance) => {
    let aliases = ['t', 'i18n'];
    TCustomAttribute.configureAliases(aliases);

    // register backend plugin
    instance.i18next.use(Backend.with(au.loader));

    // adapt options to your needs (see http://i18next.com/docs/options/)
    // make sure to return the promise of the setup method, in order to guarantee proper loading
    return instance.setup({
        backend: {                                   // <-- configure backend settings
            loadPath: './locales/{{lng}}/{{ns}}.json', // <-- XHR settings for where to get the files from
        },
        resources: resBundle,
        preload: ['en', 'de'],
        defaultNS: 'global',
        attributes: aliases,
        lng : 'en',
        fallbackLng : 'de',
        debug : true,
        ns: ['nav']
    });
});

  await au.start();
  await au.setRoot(PLATFORM.moduleName('app')); // Note the PLATFORM.moduleName
}
