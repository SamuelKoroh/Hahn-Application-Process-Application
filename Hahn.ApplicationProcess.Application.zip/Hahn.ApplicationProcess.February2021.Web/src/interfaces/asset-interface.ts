export interface ICreateAsset {
    assetName: string | undefined;
    department: number | undefined;
    countryOfDepartment: string | undefined;
    eMailAddressOfDepartment: string | undefined;
    purchaseDate: Date | undefined;
    broken: boolean | undefined;
}

export interface IDepartment {
    id: number;
    name: string;
    key?: string;
}

export interface IAsset {
    id: number;
    assetName: string;
    department: string | number;
    countryOfDepartment: string;
    eMailAddressOfDepartment: string;
    purchaseDate: Date;
    broken?: boolean;
    createdOn?: Date;
    updatedOn?: Date;
    departmentId?: number;
}

export interface IPaging {
    pageNumber: number;
    hasNextPage: boolean;
    hasPreviousPage: boolean;
    pageCount: number,
    pageSize: number,
    totalItemCount: number
}
export class ISuccessResponse<T> {
    success: boolean;
    message: string;
    data: T;
}

export class ISuccessPagingResponse<T> {
    success: boolean;
    message: string;
    data: T;
    paging: IPaging
}

export interface IError {
    success: boolean;
    message: string;
    errors: Array<IValidationError> | undefined;
}


export interface IValidationError {
    fieldName: string;
    message: Array<string>;
}
