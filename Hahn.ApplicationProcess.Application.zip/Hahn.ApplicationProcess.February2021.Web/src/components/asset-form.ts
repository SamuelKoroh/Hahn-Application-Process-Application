import { LocaleService } from './../services/locale-service';
import {inject} from 'aurelia-dependency-injection';
import {
    ValidationControllerFactory,
  ValidationController,
  ValidationRules,
  validateTrigger
} from 'aurelia-validation';
import {DialogService} from 'aurelia-dialog';
import {Router} from 'aurelia-router';
import moment from 'moment';
import {BootstrapFormRenderer} from './bootstrap-form-renderer';
import { ErrorModal } from './modals/error-modal';
import { ConfirmActionModal } from './modals/confirm-modal';
import { IDepartment, ISuccessResponse, IAsset, ICreateAsset, IError } from './../interfaces/asset-interface';
import { CountryService } from './../services/country-service';
import { AssetService } from './../services/asset-service';

@inject(ValidationControllerFactory, AssetService, DialogService, 
    CountryService, Router, LocaleService)
export class AssetForm {
    assetService: AssetService;
    localeService: LocaleService;
    dialogService: DialogService
    controller: ValidationController = null;
    countryService: CountryService;
    router: Router;

    departments: Array<IDepartment> = [];
    isEditMode: boolean = false;
    assetId: number = undefined;
    
    originalAsset: ICreateAsset = undefined;

    asset: ICreateAsset = {
        assetName: undefined,
        countryOfDepartment: undefined,
        department: undefined,
        eMailAddressOfDepartment: undefined,
        purchaseDate: undefined,
        broken: undefined,
    };

    constructor(controllerFactory, AssetService, DialogService, 
        CountryService, Router, LocaleService) {
      this.controller = controllerFactory.createForCurrentScope();
      this.controller.addRenderer(new BootstrapFormRenderer());
      this.controller.validateTrigger=validateTrigger.changeOrBlur;
      this.assetService = AssetService;
      this.dialogService = DialogService;
      this.countryService = CountryService;
      this.localeService = LocaleService;
      this.router = Router;
    }

    async activate(params){
        this.loadDepartments();

        if (params.id){
            const response = await this.assetService.getAsset(params.id);
            const successResponse = <ISuccessResponse<IAsset>>response
            
            if (response.success ){
                const asset = successResponse.data;
                this.originalAsset = <ICreateAsset>asset;
                this.originalAsset.department = asset.departmentId;
                this.asset = this.originalAsset;
                this.assetId = asset.id;
                this.isEditMode = true;
            }
            else
                return this.router.navigateToRoute('home');
        }

        if (!params.id)
            this.resetForm();
        
        ValidationRules.customRule(
            'purchaseDate',
            (value, obj) => value === null || value === undefined || value instanceof Date || moment().diff(value, 'years', true) <= 1,
            `\${$displayName} must be a valid date and not more than 1 year.`
          );

        ValidationRules.customRule(
            'countryOfDepartment',
            async (value, obj) => value === null || value === undefined || value instanceof String || await this.countryService.validateCountry(value),
            `\${$displayName} Country not valid`
            );

        ValidationRules
        .ensure((a:ICreateAsset) => a.assetName).required().minLength(5)
        .ensure(a => a.department).range(1, 5).required().withMessage("Select valid department")
        .ensure(a => a.eMailAddressOfDepartment).required().matches(/(.+)@(.+){2,}\.(.+){2,}/)
        .ensure(a => a.purchaseDate).satisfiesRule('purchaseDate')
        .ensure(a => a.countryOfDepartment).satisfiesRule('countryOfDepartment')
        .on(this.asset);
    }

    deactivate() {
        this.controller.removeRenderer(new BootstrapFormRenderer());
    }
    
    get canSubmit(){
        return this.asset.assetName 
        && this.asset.countryOfDepartment 
        && this.asset.department 
        && this.asset.purchaseDate 
        && this.asset.eMailAddressOfDepartment
        && this.controller.errors.length ===0;
    }

    get canReset(){
        return this.asset.assetName 
        || this.asset.countryOfDepartment 
        || this.asset.department 
        || this.asset.broken 
        || this.asset.purchaseDate 
        || this.asset.eMailAddressOfDepartment;
    }

   async submit() {
        const response: ISuccessResponse<IAsset> | IError =  this.isEditMode && this.assetId ? 
                await this.assetService.updateAsset(this.asset, this.assetId) :
                await this.assetService.createAsset(this.asset);

        if(response.success){
            const successResponse = <ISuccessResponse<IAsset>>response
            return this.router.navigateToRoute('asset-details', {id: successResponse.data.id });
        }

        await this.dialogService.open( {viewModel: ErrorModal, model: <IError>response });
    }

    reset(){
        this.dialogService.open( {viewModel: ConfirmActionModal, model:  this.localeService.translate('nav:dialogResetForm')}).whenClosed(response => {
            if (!response.wasCancelled) {
                this.resetForm();
                this.assetId = this.assetId || undefined;
                this.isEditMode = this.originalAsset !== undefined;
            }
        });
    }

    loadDepartments(){
        this.assetService.getDepartments().then(response => response.response)
        .then(data => {
            const result: ISuccessResponse<Array<IDepartment>> = JSON.parse(data);
            this.departments = [{id: null, name: ''}, ...result.data];
        })
        .catch(err => console.log(err));
    }

    private resetForm(){
        const originalAsset = this.originalAsset;

        this.asset = {
            assetName: originalAsset && originalAsset.assetName || undefined,
            countryOfDepartment: originalAsset && originalAsset.countryOfDepartment ||undefined,
            department: originalAsset && originalAsset.department ||undefined,
            eMailAddressOfDepartment: originalAsset && originalAsset.eMailAddressOfDepartment || undefined,
            purchaseDate: originalAsset && originalAsset.purchaseDate ||undefined,
            broken: originalAsset && originalAsset.broken || undefined
        };
    }
}