import { LocaleService } from './../services/locale-service';
import { ErrorModal } from './modals/error-modal';
import { inject } from "aurelia-dependency-injection";
import { IDepartment, IAsset, IPaging, ISuccessPagingResponse, IError,  ISuccessResponse } from './../interfaces/asset-interface';
import { AssetService } from './../services/asset-service';
import {DialogService} from 'aurelia-dialog';
import { ConfirmActionModal } from './modals/confirm-modal';

@inject(AssetService, DialogService, LocaleService)
export class AssetList{
    dialogService: DialogService;
    assetService: AssetService
    localService: LocaleService;

    departments: Array<IDepartment> = [];
    assets: Array<IAsset> = [];
    selectedDepartment: IDepartment = undefined;
    
    paging: IPaging = {
        pageNumber: 1,
        pageSize: 20,
        hasNextPage: false,
        hasPreviousPage: false,
        pageCount: 0,
        totalItemCount: 0
    };
    
    constructor(AssetService, DialogService, LocaleService){
        this.assetService = AssetService;
        this.dialogService = DialogService;
        this.localService = LocaleService;
    }

    activate(){
        this.loadDepartments();
        this.loadAssets(this.selectedDepartment?.id, 1, this.paging.pageSize);
    }

    loadDepartments(){
        this.assetService.getDepartments().then(response => response.response)
        .then(data => {
            const result: ISuccessResponse<Array<IDepartment>> = JSON.parse(data);
            const departments = result.data;

            this.departments = [{id: undefined, name: 'All Department', key: 'allDepartment'}, ...departments];
        })
        .catch(err => console.log(err));
    }

    loadAssets(departmentId: number | undefined, page: number = 1, pageSize: number = 20){
        this.assetService.getAssets(departmentId, page, pageSize).then(response => response.response)
        .then(data => {
            const result: ISuccessPagingResponse<Array<IAsset>> = JSON.parse(data);
            console.log(result);
            this.assets = [...result.data];
            this.paging = result.paging;
        })
        .catch(err => console.log(err));
    }

    onDepartmentSelected(department){
        console.log(department);
        this.selectedDepartment = department;
        console.log(this.selectedDepartment);
        this.loadAssets(this.selectedDepartment.id);
    }

    onPageSizeChanged(pageSize: number){
        console.log(pageSize);
        this.paging.pageSize = pageSize;
        this.loadAssets(this.selectedDepartment?.id, 1, this.paging.pageSize);
    }

    async deleteAsset(asset: IAsset){
        this.dialogService.open( {viewModel: ConfirmActionModal, model: this.localService.translate('nav:dialogDeleteForm') })
        .whenClosed(async response => {
            if (!response.wasCancelled) {
                const response: ISuccessResponse<IAsset> | IError =  await this.assetService.deleteAsset(asset.id);

                if(!response.success)
                    await this.dialogService.open( {viewModel: ErrorModal, model: <IError>response });
                else{
                    const filterAsset = this.assets.filter(x => x.id !== asset.id);
                    this.assets = filterAsset;
                }
            }
        });
    }

    nextPage() {
        this.loadAssets(this.selectedDepartment?.id, this.paging.pageNumber + 1, this.paging.pageSize);
    }

    previousPage() {
        this.loadAssets(this.selectedDepartment?.id, this.paging.pageNumber - 1, this.paging.pageSize);
    }

    get positionText () {
        const endIndex = this.paging.pageNumber * this.paging.pageSize,
          startIndex = ((this.paging.pageNumber - 1) * this.paging.pageSize) + 1;
  
        return "Showing "+startIndex+ " to "+ (endIndex >this.paging.totalItemCount ? this.paging.totalItemCount : endIndex)  + " of " + this.paging.totalItemCount;
    }
}