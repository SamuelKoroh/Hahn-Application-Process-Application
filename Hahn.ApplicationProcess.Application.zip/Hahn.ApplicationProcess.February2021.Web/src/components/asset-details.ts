import { Router } from 'aurelia-router';
import { AssetService } from './../services/asset-service';
import { inject } from 'aurelia-dependency-injection';
import { IAsset, ISuccessResponse } from './../interfaces/asset-interface';

@inject(AssetService, Router)
export class AssetDetails {
    asset: IAsset;
    assetService: AssetService;
    router: Router;

    constructor(AssetService, Router){
        this.assetService = AssetService;
        this.router = Router;
    }
    
    async activate(params){
        const response = await this.assetService.getAsset(params.id);
        const successResponse = <ISuccessResponse<IAsset>>response
        
        if (!response.success )
            this.router.navigate('');

        this.asset = response.success && successResponse.data;
    }
}