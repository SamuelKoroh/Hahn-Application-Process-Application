import { IError } from './../../interfaces/asset-interface';
import {inject} from 'aurelia-framework';
import {DialogController} from 'aurelia-dialog';

@inject(DialogController)

export class ErrorModal {
   controller: DialogController;
   answer: any;
   error: IError;

   constructor(controller) {
      this.controller = controller;
      this.answer = null;

      controller.settings.centerHorizontalOnly = true;
   }
   
   activate(error: IError) {
      this.error = error;
      console.log(error)
   }
}