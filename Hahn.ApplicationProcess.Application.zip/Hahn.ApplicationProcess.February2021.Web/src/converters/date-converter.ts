import moment from 'moment';

export class DateFormatValueConverter {
   toView(value) {
      return moment(value).format('YYYY-DD-MM HH:MM:SS');
   }
}

export class StringToLowerFormatValueConverter {
   toView(value: string) {
      return value.toLowerCase();
   }
}