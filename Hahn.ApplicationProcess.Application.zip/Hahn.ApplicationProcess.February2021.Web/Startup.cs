using FluentValidation.AspNetCore;
using Hahn.ApplicationProcess.February2021.Data.DataAccess;
using Hahn.ApplicationProcess.February2021.Data.HTTPDataAccess;
using Hahn.ApplicationProcess.February2021.Domain.BusinessLogics;
using Hahn.ApplicationProcess.February2021.Domain.Interfaces.BusinessLogics;
using Hahn.ApplicationProcess.February2021.Domain.Interfaces.DataAccess;
using Hahn.ApplicationProcess.February2021.Domain.Interfaces.HTTPDataAccess;
using Hahn.ApplicationProcess.February2021.Domain.Mappings;
using Hahn.ApplicationProcess.February2021.Domain.Validators;
using Hahn.ApplicationProcess.February2021.Web.SwaggerOptions.ResponseExample;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Serilog;
using Swashbuckle.AspNetCore.Filters;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text.Json;

namespace Hahn.ApplicationProcess.February2021.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<DataContext>(opt => opt.UseInMemoryDatabase("HahnDB"));
            services.AddHttpClient("RestCountries", opt =>
            {
                opt.BaseAddress = new Uri("https://restcountries.eu");
            });

            services.AddAutoMapper(typeof(AssetProfile));

            services.AddScoped<IAssetBusinessLogic, AssetBusinessLogic>();
            services.AddScoped<ICountryService, CountryService>();
            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddTransient<IConfigureOptions<SwaggerGenOptions>, ConfigureSwaggerOptions>();

            services.AddHttpContextAccessor();
            services.AddCors();

            services.AddApiVersioning(config =>
            {
                config.ReportApiVersions = true;
                config.AssumeDefaultVersionWhenUnspecified = true;
                config.DefaultApiVersion = new ApiVersion(1, 0);
                config.ApiVersionReader = new HeaderApiVersionReader("api-version");
            });

            services.AddVersionedApiExplorer(config =>
            {
                config.GroupNameFormat = "'v'VVV";
                config.SubstituteApiVersionInUrl = true;
            });

            services.AddSwaggerExamples();
            services.AddSwaggerGen(opt =>
            {
                opt.ExampleFilters();
                opt.OperationFilter<VersionOperationFilter>();
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                opt.IncludeXmlComments(xmlPath);
            });
            services.AddSwaggerExamplesFromAssemblyOf(typeof(AssetCreatedExample));
            
            services.AddRazorPages();
            services.AddControllers().AddFluentValidation(opt => opt.RegisterValidatorsFromAssemblyContaining<CreateAssetDTOValidator>());
            services.Configure<RouteOptions>(options => options.LowercaseUrls = true);
            services.Configure<ApiBehaviorOptions>(config =>
            {
                config.InvalidModelStateResponseFactory = context =>
                {
                    var errors = context.ModelState.Where(e => e.Value.Errors.Count > 0)
                        .Select(e => new
                        {
                            FieldName = e.Key,
                            Message = e.Value.Errors.Select(e => e.ErrorMessage).ToList()
                        });

                    return new BadRequestObjectResult(new
                    { Success = false, Message = "Validation Error", errors });
                };
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, IApiVersionDescriptionProvider provider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(
                options =>
                {
                    foreach (var description in provider.ApiVersionDescriptions)
                    {
                        options.SwaggerEndpoint(
                            $"/swagger/{description.GroupName}/swagger.json",
                            description.GroupName.ToUpperInvariant());
                    }
                });
            }
            else
            {
                app.UseExceptionHandler(error =>
                {
                    error.Run(async context =>
                    {
                        context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                        context.Response.ContentType = "application/json";

                        var contextError = context.Features.Get<IExceptionHandlerFeature>();

                        if (contextError != null)
                        {
                            await context.Response.WriteAsync(JsonSerializer.Serialize(new { Success = false, Message = "An unexpected error occurred" }));
                        }
                    });
                });
            }
            app.Use(next => context =>
            {
                context.Request.EnableBuffering();
                return next(context);
            });

            app.UseCors(x => x.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
            app.UseFileServer();

            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
