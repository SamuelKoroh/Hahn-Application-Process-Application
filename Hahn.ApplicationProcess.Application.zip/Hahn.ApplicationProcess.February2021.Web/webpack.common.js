const { resolve, join } = require('path');
const ProvidePlugin = require('webpack/lib/ProvidePlugin')
const { AureliaPlugin, ModuleDependenciesPlugin, GlobDependenciesPlugin } = require("aurelia-webpack-plugin"); 

const bundleOutputDir = "./wwwroot/dist";

module.exports = {
    target: "web",
    entry: {
        app: ["es6-promise/auto", "aurelia-bootstrapper"]
    },
    output: {
        path: resolve(bundleOutputDir),
        publicPath: "dist/",
        filename: "[name].[hash].js",
        chunkFilename: "[name].[chunkhash].js",
        pathinfo: false
    },
    module: {
        rules: [
            {
                test: /\.html$/,
                use: ['html-loader']
            },
            { 
                test: /\.ts$/i, 
                loader: 'ts-loader' 
            },
            {
                test: /\.(jpe?g|gif|png|svg)$/,
                loader: 'file-loader?name=images/[name].[ext]'
            },
            {
                test: /\.(eot|woff|woff2|ttf)$/,
                loader: 'file-loader?name=fonts/[name].[ext]'
            }
        ]
    },
    resolve: {
    extensions: ['.ts', '.js'],
    modules: [
        resolve(__dirname, 'src'),
        resolve(__dirname, 'node_modules'),
        resolve(__dirname, 'node_modules/aurelia-dialog/dist/umd/dialog-aurelia.js'),
        ],
        alias: {
          'jquery': join(__dirname, 'node_modules/jquery/src/jquery')
      }
    },
    plugins: [
        new AureliaPlugin(),
        new GlobDependenciesPlugin({ "main": ["src/**/*.{ts,html}"] }),
        new ModuleDependenciesPlugin({}),
        new ProvidePlugin({
            $: "jquery",
            jQuery: "jquery",
            'window.jQuery': 'jquery',
            'window.Tether': 'tether',
            Tether: 'tether'
        })
    ],
    devServer: {
        contentBase: "wwwroot/",
        compress: true,
        writeToDisk: true,
        hot: false
    }
  };