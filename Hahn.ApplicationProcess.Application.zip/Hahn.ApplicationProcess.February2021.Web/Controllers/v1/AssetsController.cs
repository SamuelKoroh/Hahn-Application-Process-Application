﻿using AutoMapper;
using Hahn.ApplicationProcess.February2021.Domain.DTOs.Requests;
using Hahn.ApplicationProcess.February2021.Domain.DTOs.Responses;
using Hahn.ApplicationProcess.February2021.Domain.Interfaces.BusinessLogics;
using Hahn.ApplicationProcess.February2021.Domain.Models;
using Hahn.ApplicationProcess.February2021.Web.SwaggerOptions.RequestSample;
using Hahn.ApplicationProcess.February2021.Web.SwaggerOptions.ResponseExample;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Serilog;
using Swashbuckle.AspNetCore.Annotations;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Hahn.ApplicationProcess.February2021.Web.Controllers.v1
{
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class AssetsController : ControllerBase
    {
        private readonly IAssetBusinessLogic _assetService;
        private readonly IMapper _mapper;

        public AssetsController(IAssetBusinessLogic assetService, IMapper mapper)
        {
            _assetService = assetService;
            _mapper = mapper;
        }

        [HttpPost]
        [SwaggerRequestExample(typeof(CreateAssetDTO), typeof(CreateAssetExample))]
        [SwaggerResponseExample(201, typeof(AssetCreatedExample))]
        [SwaggerResponse(201, "Create Asset", typeof(SuccessResponse<AssetDTO>))]
        [SwaggerResponseExample(409, typeof(AssetNameExistExample))]
        [SwaggerResponse(409, "Asset Name Exist", typeof(ErrorResponse))]
        [SwaggerResponse(400, Type = typeof(ErrorResponse), Description = "An invalid or missing input parameter will result in a bad request")]
        [SwaggerResponseExample(400, typeof(ValidationErrorExample))]
        public async Task<IActionResult> CreateAsset([FromBody] CreateAssetDTO createAsset)
        {
            try
            {
                var asset = _mapper.Map<Asset>(createAsset);
                var result = await _assetService.CreateAsset(asset);

                if (!result.Success)
                    return BadRequest(APIResponse.Error(result.Message));

                var data = _mapper.Map<AssetDTO>(asset);

                Log.Information("Asset created", data);

                return CreatedAtAction(nameof(GetAsset), new { id = data.Id }, APIResponse.Success(result.Message, data));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message, ex.InnerException);
                return StatusCode(500, APIResponse.Error("An unexpected error occurred"));
            }
        }

        [HttpGet]
        [SwaggerResponseExample(200, typeof(AssetsRetrievedExample))]
        [SwaggerResponse(200, "List of Assets", typeof(SuccessPagingResponse<IEnumerable<AssetDTO>>))]
        public async Task<IActionResult> GetAssets([FromQuery] AssetQueryParam assetQueryParam)
        {
            try
            {
                var result = await _assetService.GetAssets(assetQueryParam.Page, assetQueryParam.PageSize, assetQueryParam.departmentId);

                if (!result.Success)
                    return BadRequest(APIResponse.Error(result.Message));

                var data = _mapper.Map<IEnumerable<AssetDTO>>(result.Data.Item1);

                return Ok(APIResponse.Success(result.Message, data, result.Data.Item2));
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }

        /// <param name="id" example="1"></param>
        [HttpGet("{id}")]
        [SwaggerResponseExample(200, typeof(AssetRetrievedExample))]
        [SwaggerResponse(200, "Asset", typeof(SuccessResponse<AssetDTO>))]
        [SwaggerResponseExample(404, typeof(AssetNotFoundExample))]
        [SwaggerResponse(404, "Asset Not Found", typeof(ErrorResponse))]
        public async Task<IActionResult> GetAsset(int id)
        {
            try
            {
                var result = await _assetService.GetAsset(id);

                if (!result.Success)
                    return NotFound(APIResponse.Error(result.Message));

                var data = _mapper.Map<AssetDTO>(result.Data);

                return Ok(APIResponse.Success(result.Message, data));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message, ex.InnerException);
                return StatusCode(500, APIResponse.Error("An unexpected error occurred"));
            }
        }

        /// <param name="id" example="1"></param>
        /// <param name="assetDTO"></param>
        [HttpPut("{id}")]
        [SwaggerRequestExample(typeof(UpdateAssetDTO), typeof(UpdateAssetExample))]
        [SwaggerResponseExample(200, typeof(AssetUpdatedExample))]
        [SwaggerResponse(200, "Update Asset", typeof(SuccessResponse<AssetDTO>))]
        [SwaggerResponseExample(409, typeof(AssetNameExistExample))]
        [SwaggerResponse(409, "Asset Name Exist", typeof(ErrorResponse))]
        [SwaggerResponseExample(404, typeof(AssetNotFoundExample))]
        [SwaggerResponse(404, "Asset Not Found", typeof(ErrorResponse))]
        [SwaggerResponse(400, Type = typeof(ErrorResponse), Description = "An invalid or missing input parameter will result in a bad request")]
        [SwaggerResponseExample(400, typeof(ValidationErrorExample))]
        public async Task<IActionResult> UpdateAsset(int id, [FromBody] UpdateAssetDTO assetDTO)
        {
            try
            {
                var result = await _assetService.GetAsset(id);

                if (!result.Success)
                    return NotFound(APIResponse.Error(result.Message));

                _mapper.Map(assetDTO, result.Data);

                result = await _assetService.UpdateAsset(result.Data);

                if (!result.Success)
                    return BadRequest(APIResponse.Error(result.Message));

                var data = _mapper.Map<AssetDTO>(result.Data);

                Log.Information("Asset Updated", data.ToString());

                return Ok(APIResponse.Success(result.Message, data));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message, ex.InnerException);
                return StatusCode(500, APIResponse.Error("An unexpected error occurred"));
            }
        }

        /// <param name="id" example="1"></param>
        [HttpDelete("{id}")]
        [SwaggerResponseExample(200, typeof(AssetDeletedExample))]
        [SwaggerResponse(200, "Delete Asset", typeof(SuccessResponse<AssetDTO>))]
        [SwaggerResponseExample(404, typeof(AssetNotFoundExample))]
        [SwaggerResponse(404, "Asset Not Found", typeof(ErrorResponse))]
        public async Task<IActionResult> DeleteAsset(int id)
        {
            try
            {
                var result = await _assetService.DeleteAsset(id);

                if (!result.Success)
                    return BadRequest(APIResponse.Error(result.Message));

                var data = _mapper.Map<AssetDTO>(result.Data);

                return Ok(APIResponse.Success(result.Message, data));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message, ex.InnerException);
                return StatusCode(500, APIResponse.Error("An unexpected error occurred"));
            }
        }

        [HttpGet("departments")]
        [SwaggerResponseExample(200, typeof(DepartmentsRetrievedExample))]
        [SwaggerResponse(200, "List of Departments", typeof(SuccessResponse<IEnumerable<DepartmentDTO>>))]
        public IActionResult GetDepartments()
        {
            try
            {
                var result =  _assetService.Departments();

                return Ok(APIResponse.Success(result.Message, result.Data));
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message, ex.InnerException);
                return StatusCode(500, APIResponse.Error("An unexpected error occurred"));
            }
        }
    }
}
