﻿using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Collections.Generic;
using System.Linq;

namespace Hahn.ApplicationProcess.February2021.Web
{
    public class VersionOperationFilter : IOperationFilter
    {
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            var version = operation.Parameters.SingleOrDefault(x => x.Name == "version" && x.In == ParameterLocation.Path);

            if(version != null)
            {
                version.Schema = new OpenApiSchema
                {
                    Type = "string",
                    Default = new OpenApiString("1")
                };
            }
        }
    }
}
