﻿using Hahn.ApplicationProcess.February2021.Domain.DTOs.Responses;
using Swashbuckle.AspNetCore.Filters;
using System.Collections.Generic;

namespace Hahn.ApplicationProcess.February2021.Web.SwaggerOptions.ResponseExample
{
    public class ValidationErrorExample : IExamplesProvider<ErrorResponse>
    {
        public ErrorResponse GetExamples()
        {
            return new ErrorResponse
            {
                Message = "Asset with this name already exists!",
                Success = false,
                Errors = new List<object>
                {
                    new  {
                            fieldName= "Broken",
                            message = new List<string>
                            {
                                "Broken value cannot be null if provided"
                            }
                        },
                    new {
                            fieldName= "AssetName",
                            message= new List<string>
                            {
                                "The length of 'Asset Name' must be at least 5 characters. You entered 0 characters.",
                                "'Asset Name' must not be empty."
                            }
                        },
                    new {
                            fieldName= "Department",
                            message= new List<string>
                            {
                                "The department does not exists!"
                            }
                        },
                    new {
                            fieldName= "PurchaseDate",
                            message= new List<string>
                            {
                                "Purchase date must not be older than 1 year"
                            }
                        },
                    new {
                            fieldName= "CountryOfDepartment",
                            message= new List<string>
                            {
                                "Country does not exists!"
                            }
                        },
                    new {
                            fieldName= "EMailAdressOfDepartment",
                            message= new List<string>
                            {
                            "'E Mail Adress Of Department' is not a valid email address."
                            }
                        }
                }
            };
        }
    }
}