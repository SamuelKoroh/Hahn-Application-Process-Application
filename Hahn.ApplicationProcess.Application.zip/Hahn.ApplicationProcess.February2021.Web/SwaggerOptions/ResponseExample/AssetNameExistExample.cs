﻿using Hahn.ApplicationProcess.February2021.Domain.DTOs.Responses;
using Swashbuckle.AspNetCore.Filters;

namespace Hahn.ApplicationProcess.February2021.Web.SwaggerOptions.ResponseExample
{
    public class AssetNameExistExample : IExamplesProvider<ErrorResponse>
    {
        public ErrorResponse GetExamples()
        {
            return new ErrorResponse
            {
                Message = "Asset with this name already exists!",
                Success = false,
                Errors = null
            };
        }
    }
}