﻿using Hahn.ApplicationProcess.February2021.Domain.DTOs.Responses;
using Swashbuckle.AspNetCore.Filters;

namespace Hahn.ApplicationProcess.February2021.Web.SwaggerOptions.ResponseExample
{
    public class AssetNotFoundExample : IExamplesProvider<ErrorResponse>
    {
        public ErrorResponse GetExamples()
        {
            return new ErrorResponse
            {
                Message = "Asset not found!",
                Success = false,
                Errors = null
            };
        }
    }
}
