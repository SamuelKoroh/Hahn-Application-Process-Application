﻿using Hahn.ApplicationProcess.February2021.Domain.DTOs.Responses;
using Hahn.ApplicationProcess.February2021.Domain.Enums;
using Hahn.ApplicationProcess.February2021.Domain.Utilities;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;

namespace Hahn.ApplicationProcess.February2021.Web.SwaggerOptions.ResponseExample
{
    public class AssetsRetrievedExample : IExamplesProvider<SuccessPagingResponse<IEnumerable<AssetDTO>>>
    {
        public SuccessPagingResponse<IEnumerable<AssetDTO>> GetExamples()
        {
            return new SuccessPagingResponse<IEnumerable<AssetDTO>>
            {
                Success = true,
                Data = new List<AssetDTO>
                {
                    new AssetDTO
                    {
                        Id = 1,
                        AssetName = "Tractor",
                        CountryOfDepartment = "UK",
                        Department = DepartmentEnum.Store1.ToString(),
                        EMailAddressOfDepartment = "tractor@store.com",
                        PurchaseDate = DateTime.UtcNow,
                        Broken = false,
                        UpdatedOn = DateTime.UtcNow,
                        CreatedOn = DateTime.UtcNow,
                    }
                },
                Message = "Assets retrieved successfully",
                Paging = new PaginationMetaData(page: 1, 20, 200)
            };
        }
    }
}
