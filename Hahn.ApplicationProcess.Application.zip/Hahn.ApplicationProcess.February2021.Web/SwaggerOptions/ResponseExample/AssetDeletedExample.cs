﻿using Hahn.ApplicationProcess.February2021.Domain.DTOs.Responses;
using Hahn.ApplicationProcess.February2021.Domain.Enums;
using Swashbuckle.AspNetCore.Filters;
using System;

namespace Hahn.ApplicationProcess.February2021.Web.SwaggerOptions.ResponseExample
{
    public class AssetDeletedExample : IExamplesProvider<SuccessResponse<AssetDTO>>
    {
        public SuccessResponse<AssetDTO> GetExamples()
        {
            return new SuccessResponse<AssetDTO>
            {
                Success = true,
                Data = new AssetDTO
                {
                    Id = 1,
                    AssetName = "Tractor",
                    CountryOfDepartment = "UK",
                    Department = DepartmentEnum.Store1.ToString(),
                    EMailAddressOfDepartment = "tractor@store.com",
                    PurchaseDate = DateTime.UtcNow,
                    Broken = false,
                    UpdatedOn = DateTime.UtcNow,
                    CreatedOn = DateTime.UtcNow,
                },
                Message = "Asset deleted successfully"
            };
        }
    }
}
