﻿using Hahn.ApplicationProcess.February2021.Domain.DTOs.Responses;
using Hahn.ApplicationProcess.February2021.Domain.Enums;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;

namespace Hahn.ApplicationProcess.February2021.Web.SwaggerOptions.ResponseExample
{
    public class DepartmentsRetrievedExample : IExamplesProvider<SuccessResponse<List<DepartmentDTO>>>
    {
        public SuccessResponse<List<DepartmentDTO>> GetExamples()
        {
            return new SuccessResponse<List<DepartmentDTO>>
            {
                Success = true,
                Data = new List<DepartmentDTO>
                {
                    new DepartmentDTO
                    {
                        Id = 1,
                        Name = DepartmentEnum.Store1.ToString(),
                    }
                },
                Message = "Departments retrieved successfully"
            };
        }
    }
}
