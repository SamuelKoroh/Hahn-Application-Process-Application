﻿using Hahn.ApplicationProcess.February2021.Domain.DTOs.Requests;
using Hahn.ApplicationProcess.February2021.Domain.Enums;
using Swashbuckle.AspNetCore.Filters;
using System;

namespace Hahn.ApplicationProcess.February2021.Web.SwaggerOptions.RequestSample
{
    public class CreateAssetExample : IExamplesProvider<CreateAssetDTO>
    {
        public CreateAssetDTO GetExamples()
        {
            return new CreateAssetDTO
            {
                AssetName = "Tractor",
                CountryOfDepartment = "UK",
                Department = DepartmentEnum.Store1,
                EMailAddressOfDepartment = "tractor@store.com",
                PurchaseDate = DateTime.UtcNow,
                Broken = false,
            };
        }
    }
}
