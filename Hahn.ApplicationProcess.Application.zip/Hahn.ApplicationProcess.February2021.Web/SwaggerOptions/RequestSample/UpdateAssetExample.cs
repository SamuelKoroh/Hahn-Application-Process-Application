﻿using Hahn.ApplicationProcess.February2021.Domain.DTOs.Requests;
using Hahn.ApplicationProcess.February2021.Domain.Enums;
using Swashbuckle.AspNetCore.Filters;
using System;

namespace Hahn.ApplicationProcess.February2021.Web.SwaggerOptions.RequestSample
{
    public class UpdateAssetExample : IExamplesProvider<UpdateAssetDTO>
    {
        public UpdateAssetDTO GetExamples()
        {
            return new UpdateAssetDTO
            {
                AssetName = "Tractor Updated",
                CountryOfDepartment = "Germany",
                Department = DepartmentEnum.Store3,
                EMailAddressOfDepartment = "tractor@store.com",
                PurchaseDate = DateTime.UtcNow,
                Broken = false,
            };
        }
    }
}
